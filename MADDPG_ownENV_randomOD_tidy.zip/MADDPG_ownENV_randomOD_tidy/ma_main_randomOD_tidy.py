import sys
# sys.path.append('F:\githubClone\Multi_agent_AAC\old_framework_test')
# sys.path.append('D:\Multi_agent_AAC\old_framework_test')
from env.make_env import make_env
import argparse
import datetime
import pandas as pd
import numpy as np
import torch
import os
import time
import pickle
import wandb
from parameters_randomOD_tidy import initialize_parameters
from maddpg_agent_randomOD_tidy import MADDPG
from utils_randomOD_tidy import *
from copy import deepcopy
import torch
import matplotlib.pyplot as plt
import matplotlib
from shapely.geometry import LineString, Point, Polygon
from shapely.strtree import STRtree
from matplotlib.markers import MarkerStyle
import math
from matplotlib.transforms import Affine2D
from Utilities_own_randomOD_tidy import *
import csv

num_devices = torch.cuda.device_count()
print("Number of GPUs:", num_devices)
# Get the names of the available GPUs
gpu_names = [torch.cuda.get_device_name(i) for i in range(num_devices)]
print("GPU Names:", gpu_names)
if torch.cuda.is_available():
    device = torch.device('cuda')
    print('Using GPU')
else:
    device = torch.device('cpu')
    print('Using CPU')


def main(args):

    if args.mode == "train":
        today = datetime.date.today()
        current_date = today.strftime("%d%m%y")
        current_time = datetime.datetime.now()
        formatted_time = current_time.strftime("%H_%M_%S")
        file_name = 'D:\MADDPG_2nd_jp/' + str(current_date) + '_' + str(formatted_time)
        if not os.path.exists(file_name):
            os.makedirs(file_name)
        plot_file_name = file_name + '/toplot'
        if not os.path.exists(plot_file_name):
            os.makedirs(plot_file_name)

    use_wanDB = False
    # use_wanDB = True

    if use_wanDB:
        wandb.login(key="efb76db851374f93228250eda60639c70a93d1ec")
        wandb.init(
            # set the wandb project where this run will be logged
            project="MADDPG_FrameWork",
            name='MADDPG_test_'+str(current_date) + '_' + str(formatted_time),
            # track hyperparameters and run metadata
            config={
                # "learning_rate": args.a_lr,
                "epochs": args.max_episodes,
            }
        )

    # -------------- create my own environment -----------------
    n_episodes, max_t, eps_start, eps_end, eps_period, eps, env, \
    agent_grid_obs, BUFFER_SIZE, BATCH_SIZE, GAMMA, TAU, learning_rate, UPDATE_EVERY, seed_used, max_xy = initialize_parameters()
    # total_agentNum = len(pd.read_excel(env.agentConfig))
    total_agentNum = 3
    UPDATE_EVERY = 30
    # max_nei_num = 5
    # create world
    # actor_dim = [6+(total_agentNum-1)*2, 10, 6]  # dim host, maximum dim grid, dim other drones
    # critic_dim = [6+(total_agentNum-1)*2, 10, 6]
    actor_dim = [6, 9, 6]  # dim host, maximum dim grid, dim other drones
    # actor_dim = [16, 9, 6]  # dim host, maximum dim grid, dim other drones
    critic_dim = [6, 9, 6]
    # critic_dim = [16, 9, 6]
    n_actions = 2
    acc_range = [-4, 4]

    actorNet_lr = 0.0001
    criticNet_lr = 0.0001

    # noise parameter ini
    largest_Nsigma = 0.5
    smallest_Nsigma = 0.15
    ini_Nsigma = largest_Nsigma

    max_spd = 15
    env.create_world(total_agentNum, n_actions, GAMMA, TAU, UPDATE_EVERY, largest_Nsigma, smallest_Nsigma, ini_Nsigma, max_xy, max_spd, acc_range)

    # --------- my own -----------
    n_agents = len(env.all_agents)
    n_actions = n_actions

    torch.manual_seed(args.seed)  # this is the seed

    if args.algo == "maddpg":
        model = MADDPG(actor_dim, critic_dim, n_actions, n_agents, args, criticNet_lr, actorNet_lr, GAMMA, TAU)

    episode = 0
    total_step = 0
    score_history = []
    eps_reward_record = []
    eps_noise_record = []
    eps_end = 5000  # at eps = eps_end, the eps value drops to lowest value which is 0.03 (this value is fixed)
    noise_start_level = 1
    if args.mode == "eval":
        # args.max_episodes = 1  # only evaluate one episode during evaluation mode.
        args.max_episodes = 10

    # while episode < args.max_episodes:
    while episode < args.max_episodes:  # start of an episode
        # ------------ my own env.reset() ------------ #

        # cur_state, norm_cur_state = env.reset_world_fixedOD(show=0)

        cur_state, norm_cur_state = env.reset_world(total_agentNum, show=0)


        episode_decision = [False] * 2
        agents_added = []
        eps_reward = []
        eps_noise = []
        episode += 1
        # print("current episode is {}, scaling factor is {}".format(episode, model.var[0]))
        step = 0
        agent_added = 0  # this is an initialization for each new episode
        accum_reward = 0

        trajectory_eachPlay = []

        pre_fix = r'D:\MADDPG_2nd_jp\211123_17_20_31\interval_record_eps'
        episode_to_check = str(20000)
        load_filepath_0 = pre_fix + '\episode_' + episode_to_check + '_agent_0actor_net.pth'
        load_filepath_1 = pre_fix + '\episode_' + episode_to_check + '_agent_1actor_net.pth'
        load_filepath_2 = pre_fix + '\episode_' + episode_to_check + '_agent_2actor_net.pth'
        # load_filepath_3 = pre_fix + '\episode_' + episode_to_check + '_agent_3actor_net.pth'
        # load_filepath_4 = pre_fix + '\episode_' + episode_to_check + '_agent_4actor_net.pth'

        if args.mode == "eval":
            # model.load_model([load_filepath_0, load_filepath_1, load_filepath_2, load_filepath_3, load_filepath_4])
            model.load_model([load_filepath_0, load_filepath_1, load_filepath_2])
        while True:  # start of an episode (this episode ends when (agent_added < max_agent_to_add))
            if args.mode == "train":
                step_reward_record = [None] * n_agents
                # cur_state, norm_cur_state = env.fill_agent_reset(cur_state, norm_cur_state, agents_added)  # if a new agent is filled, we need to reset the state information for the newly added agents
                action, step_noise_val = model.choose_action(norm_cur_state, total_step, episode, step, eps_end, noise_start_level, noisy=False) # noisy is false because we are using stochastic policy
                # action = model.choose_action(cur_state, episode, noisy=True)
                next_state, norm_next_state = env.step(action, step)
                # reward_aft_action, done_aft_action, check_goal, step_reward_record, agents_added = env.get_step_reward_5_v3(step, step_reward_record)   # remove reached agent here
                # reward_aft_action, done_aft_action, check_goal, step_reward_record = env.get_step_reward_5_v3(step, step_reward_record)   # remove reached agent here
                reward_aft_action, done_aft_action, check_goal, step_reward_record = env.ss_reward(step, step_reward_record)   # remove reached agent here
                # reward_aft_action = [eachRWD / 300 for eachRWD in reward_aft_action]  # scale the reward down
                # new_length = len(agents_added)  # check if length of agnet_to_remove increased during each step
                # agent_added = agent_added + new_length

                step += 1  # current play step
                total_step += 1  # steps taken from 1st episode
                eps_noise.append(step_noise_val)
                if args.algo == "maddpg" or args.algo == "commnet":
                    obs = []
                    next_obs = []
                    # ------------- to store norm or non-norm state into experience replay ---------------
                    for elementIdx, element in enumerate(norm_cur_state):
                    # for elementIdx, element in enumerate(cur_state):
                        if elementIdx != len(norm_cur_state)-1:  # meaning is not the last element
                        # if elementIdx != len(cur_state)-1:  # meaning is not the last element
                            obs.append(torch.from_numpy(np.stack(element)).data.float().to(device))
                        else:
                            sur_agents = []
                            for each_agent_list in element:
                                sur_agents.append(torch.from_numpy(np.squeeze(np.array(each_agent_list), axis=1)).float())
                            obs.append(sur_agents)

                    for elementIdx, element in enumerate(norm_next_state):
                    # for elementIdx, element in enumerate(cur_state):
                        if elementIdx != len(norm_next_state)-1:  # meaning is not the last element
                        # if elementIdx != len(cur_state)-1:  # meaning is not the last element
                            next_obs.append(torch.from_numpy(np.stack(element)).data.float().to(device))
                        else:
                            sur_agents = []
                            for each_agent_list in element:
                                sur_agents.append(torch.from_numpy(np.squeeze(np.array(each_agent_list), axis=1)).float())
                            next_obs.append(sur_agents)
                    # ------------------ end of store norm or non-norm state into experience replay --------------------
                    rw_tensor = torch.FloatTensor(np.array(reward_aft_action)).to(device)
                    ac_tensor = torch.FloatTensor(action).to(device)
                    done_tensor = torch.FloatTensor(done_aft_action).to(device)
                    if args.algo == "commnet" and next_obs is not None:
                        model.memory.push(obs.data, ac_tensor, next_obs, rw_tensor, done_tensor)
                    if args.algo == "maddpg":
                        model.memory.push(obs, ac_tensor, next_obs, rw_tensor, done_tensor)
                else:
                    model.memory(cur_state, action, reward_aft_action, next_state, done_aft_action)

                # accum_reward = accum_reward + reward_aft_action[0]  # we just take the first agent's reward, because we are using a joint reward, so all agents obtain the same reward.
                accum_reward = accum_reward + sum(reward_aft_action)

                c_loss, a_loss = model.update_myown(episode, total_step, UPDATE_EVERY, wandb)  # last working learning framework

                cur_state = next_state
                norm_cur_state = norm_next_state
                eps_reward.append(step_reward_record)

                if ((args.episode_length < step) and (300 not in reward_aft_action)):
                    episode_decision[0] = True
                    print("Agents stuck in some places, maximum step in one episode reached, current episode {} ends".format(episode))
                elif (True in done_aft_action):
                    episode_decision[1] = True
                    print("Some agent triggers termination condition like collision, current episode {} ends".format(episode))
                # elif (agent_added>50):
                #     episode_decision[2] = True
                #     print("More than 50 drones has reaches the destination, current episode {} ends".format(episode))
                # if ((args.episode_length < step) and (300 not in reward_aft_action)) or (True in done_aft_action) or (agent_added>50):
                if True in episode_decision:
                    # c_loss, a_loss = model.update_myown(episode, total_step, UPDATE_EVERY, wandb)  # last working learning framework
                    # time_used = time.time() - start_time
                    # print("update function used {} seconds to run".format(time_used))
                    # here onwards is end of an episode's play
                    score_history.append(accum_reward)

                    # print("[Episode %05d] reward %6.4f time used is %.2f sec" % (episode, accum_reward, time_used))
                    print("[Episode %05d] reward %6.4f" % (episode, accum_reward))
                    if use_wanDB:
                        wandb.log({'overall_reward': float(accum_reward)})
                    with open(file_name + '/GFG.csv', 'w') as f:
                        # using csv.writer method from CSV package
                        write = csv.writer(f)
                        write.writerows([score_history])
                    if c_loss and a_loss:
                        for idx, val in enumerate(c_loss):
                            print(" agent %s, a_loss %3.2f c_loss %3.2f" % (idx, a_loss[idx].item(), c_loss[idx].item()))
                            # wandb.log({'agent' + str(idx) + 'actor_loss': float(a_loss[idx].item())})
                            # wandb.log({'agent' + str(idx) + 'critic_loss': float(c_loss[idx].item())})
                    if episode % args.save_interval == 0 and args.mode == "train":
                        # save the models at a predefined interval
                        # save model to my own directory
                        filepath = file_name+'/interval_record_eps'
                        model.save_model(episode, filepath)  # this is the original save model

                    # save episodes reward for entire system at each of one episode
                    eps_reward_record.append(eps_reward)
                    eps_noise_record.append(eps_noise)
                    with open(plot_file_name + '/all_episode_reward.pickle', 'wb') as handle:
                        pickle.dump(eps_reward_record, handle, protocol=pickle.HIGHEST_PROTOCOL)
                    with open(plot_file_name + '/all_episode_noise.pickle', 'wb') as handle:
                        pickle.dump(eps_noise_record, handle, protocol=pickle.HIGHEST_PROTOCOL)

                    break  # this is to break out from "while True:", which is one play
            elif args.mode == "eval":

                step_reward_record = [None] * n_agents
                action, step_noise_val = model.choose_action(norm_cur_state, total_step, episode, step, eps_end, noise_start_level, noisy=False)
                # action = model.choose_action(cur_state, episode, noisy=False)
                # action = env.get_actions_noCR()  # only update heading, don't update any other attribute
                next_state, norm_next_state = env.step(action, step)  # no heading update here
                reward_aft_action, done_aft_action, check_goal, step_reward_record = env.ss_reward(step, step_reward_record)
                # reward_aft_action, done_aft_action, check_goal, step_reward_record = env.get_step_reward_5_v3(step, step_reward_record)

                step += 1
                total_step += 1
                cur_state = next_state
                norm_cur_state = norm_next_state
                trajectory_eachPlay.append([[each_agent_traj[0], each_agent_traj[1]] for each_agent_traj in cur_state[0]])
                accum_reward = accum_reward + sum(reward_aft_action)

                if args.episode_length < step or (True in done_aft_action):  # when termination condition reached
                    print("[Episode %05d] reward %6.4f " % (episode, accum_reward))
                    # display trajectory
                    os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
                    matplotlib.use('TkAgg')
                    fig, ax = plt.subplots(1, 1)
                    # display initial condition
                    # global_state = env.reset_world(show=0)  # just a dummy to reset all condition so that initial condition can be added to the output graph
                    for agentIdx, agent in env.all_agents.items():
                        plt.plot(agent.ini_pos[0], agent.ini_pos[1],
                                 marker=MarkerStyle(">",
                                                    fillstyle="right",
                                                    transform=Affine2D().rotate_deg(math.degrees(agent.heading))),
                                 color='y')
                        plt.text(agent.ini_pos[0], agent.ini_pos[1], agent.agent_name)
                        # plot self_circle of the drone
                        self_circle = Point(agent.ini_pos[0],
                                            agent.ini_pos[1]).buffer(agent.protectiveBound, cap_style='round')
                        grid_mat_Scir = shapelypoly_to_matpoly(self_circle, inFill=False, Edgecolor='k')
                        ax.add_patch(grid_mat_Scir)

                        # plot drone's detection range
                        detec_circle = Point(agent.ini_pos[0],
                                             agent.ini_pos[1]).buffer(agent.detectionRange / 2, cap_style='round')
                        detec_circle_mat = shapelypoly_to_matpoly(detec_circle, inFill=False, Edgecolor='g')
                        ax.add_patch(detec_circle_mat)

                        # link individual drone's starting position with its goal
                        ini = agent.ini_pos
                        # for wp in agent.goal:
                        #     plt.plot(wp[0], wp[1], marker='*', color='y', markersize=10)
                        #     plt.plot([wp[0], ini[0]], [wp[1], ini[1]], '--', color='c')
                        #     ini = wp
                        plt.plot(agent.goal[-1][0], agent.goal[-1][1], marker='*', color='y', markersize=10)
                        plt.text(agent.goal[-1][0], agent.goal[-1][1], agent.agent_name)
                    # draw trajectory in current episode
                    for trajectory_idx, trajectory_val in enumerate(trajectory_eachPlay):  # each time step
                        for agentIDX, each_agent_traj in enumerate(trajectory_val):  # for each agent's motion in a time step
                            x, y = each_agent_traj[0], each_agent_traj[1]
                            plt.plot(x, y, 'o', color='r')

                            # plt.text(x-1, y-1, str(round(float(reward_each_agent[trajectory_idx][agentIDX]),2)))

                            self_circle = Point(x, y).buffer(env.all_agents[0].protectiveBound, cap_style='round')
                            grid_mat_Scir = shapelypoly_to_matpoly(self_circle, False, 'k')
                            ax.add_patch(grid_mat_Scir)

                    # draw occupied_poly
                    for one_poly in env.world_map_2D_polyList[0][0]:
                        one_poly_mat = shapelypoly_to_matpoly(one_poly, True, 'y', 'b')
                        ax.add_patch(one_poly_mat)
                    # draw non-occupied_poly
                    for zero_poly in env.world_map_2D_polyList[0][1]:
                        zero_poly_mat = shapelypoly_to_matpoly(zero_poly, False, 'y')
                        # ax.add_patch(zero_poly_mat)

                    # show building obstacles
                    for poly in env.buildingPolygons:
                        matp_poly = shapelypoly_to_matpoly(poly, False, 'red')  # the 3rd parameter is the edge color
                        ax.add_patch(matp_poly)

                    plt.axis('equal')
                    plt.xlim(env.bound[0], env.bound[1])
                    plt.ylim(env.bound[2], env.bound[3])
                    plt.axvline(x=env.bound[0], c="green")
                    plt.axvline(x=env.bound[1], c="green")
                    plt.axhline(y=env.bound[2], c="green")
                    plt.axhline(y=env.bound[3], c="green")
                    plt.xlabel("X axis")
                    plt.ylabel("Y axis")
                    plt.show()
                    break

                # if args.episode_length < step or (True in done_aft_action):
                #     print("[Episode %05d] reward %6.4f" % (episode, accum_reward))
                #     break

    if use_wanDB:
        wandb.finish()

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--scenario', default="simple_spread", type=str)
    parser.add_argument('--max_episodes', default=15000, type=int)  # run for a total of 50000 episodes
    parser.add_argument('--algo', default="maddpg", type=str, help="commnet/bicnet/maddpg")
    parser.add_argument('--mode', default="train", type=str, help="train/eval")
    parser.add_argument('--episode_length', default=30, type=int)  # maximum play per episode
    parser.add_argument('--memory_length', default=int(1e5), type=int)
    parser.add_argument('--tau', default=0.001, type=float)
    parser.add_argument('--gamma', default=0.95, type=float)
    parser.add_argument('--seed', default=777, type=int)  # may choose to use 3407
    parser.add_argument('--batch_size', default=512, type=int)  # original 512
    parser.add_argument('--render_flag', default=False, type=bool)
    parser.add_argument('--ou_theta', default=0.15, type=float)
    parser.add_argument('--ou_mu', default=0.0, type=float)
    parser.add_argument('--ou_sigma', default=0.2, type=float)
    parser.add_argument('--epsilon_decay', default=10000, type=int)
    parser.add_argument('--tensorboard', default=True, action="store_true")
    parser.add_argument("--save_interval", default=1000, type=int)  # save model for every 5000 episodes
    parser.add_argument("--model_episode", default=60000, type=int)
    parser.add_argument('--episode_before_train', default=10, type=int)  # original 1000
    parser.add_argument('--log_dir', default=datetime.datetime.now().strftime('%Y%m%d_%H%M%S'))

    args = parser.parse_args()

    main(args)
